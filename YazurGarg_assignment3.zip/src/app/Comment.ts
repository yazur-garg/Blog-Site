export class Comment{
    _id: string | undefined
    author: string | undefined;
    comment: string | undefined;
    date: string | undefined;
}
   